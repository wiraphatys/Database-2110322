UPDATE product SET standard_price = 5400.00
WHERE product_id = 5;

UPDATE product
SET standard_price = 5400.00
WHERE product_description = 'Sofabed';

SELECT * FROM product;
