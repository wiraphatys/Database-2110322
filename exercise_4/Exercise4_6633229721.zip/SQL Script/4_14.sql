INSERT INTO product
VALUES 
	(7,'kitchen cabinet','Cherry',1500.00),
	(8,'table','Red Oak', 550.00);