SELECT COUNT(order_date) FROM ordert
WHERE order_date BETWEEN '2020-01-10' AND '2020-01-15';